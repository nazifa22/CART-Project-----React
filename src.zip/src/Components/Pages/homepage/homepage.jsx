import React from 'react';
import './homepage.scss'
import DirectoryComponent from '../../Directory/directoryComponent';

const Homepage = () => {
    return (
        <div className='homepage'>
           <DirectoryComponent />
        </div>
    )
}

export default Homepage;
