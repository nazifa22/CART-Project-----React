import React from 'react';
import Signin from './../SignIn/signin';
// import SignUp from './../Signup/signup';
import './signin-signup.scss';
import SignUp from './../Signup/sign-up.component';

const SigninSignup = () => {
    return (
        <div className="sign-in-and-sign-up">
            <Signin />
            <SignUp />
        </div>
    )
}

export default SigninSignup;
